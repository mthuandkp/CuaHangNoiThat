<?php
    require_once('./mvc/core/App.php');
    require_once('./mvc/core/Controller.php');
    require_once('./mvc/core/ConnectionDB.php');
    require_once('./mvc/core/processFunc.php');
    require_once('./mvc/core/vendor/autoload.php');
?>