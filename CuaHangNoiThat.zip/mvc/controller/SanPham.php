<?php
    class SanPham extends Controller{
        function display(){
            $this->View('SanPham');
        }
    }
?>