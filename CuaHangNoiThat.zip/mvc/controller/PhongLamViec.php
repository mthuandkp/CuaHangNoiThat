<?php
    class PhongLamViec extends Controller{
        function display(){
            $this->View('PhongLamViec');
        }
    }

?>