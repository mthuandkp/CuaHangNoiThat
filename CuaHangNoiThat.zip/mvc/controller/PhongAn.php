<?php
    class PhongAn extends Controller{
        function display(){
            $this->View('PhongAn');
        }
    }

?>