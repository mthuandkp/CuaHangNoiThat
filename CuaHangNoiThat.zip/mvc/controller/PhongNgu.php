<?php
    class PhongNgu extends Controller{
        function display(){
            $this->View('PhongNgu');
        }
    }

?>