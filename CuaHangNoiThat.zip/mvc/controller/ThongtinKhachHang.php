<?php
    class ThongTinKhachHang extends Controller{
        function display(){
            $this->View('ThongTinKhachHang');
        }
    }

?>