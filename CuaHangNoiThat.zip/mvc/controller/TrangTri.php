<?php
    class TrangTri extends Controller{
        function display(){
            $this->View('TrangTri');
        }
    }

?>