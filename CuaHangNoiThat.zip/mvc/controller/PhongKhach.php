<?php
    class PhongKhach extends Controller{
        function display(){
            $this->View('PhongKhach');
        }
    }

?>