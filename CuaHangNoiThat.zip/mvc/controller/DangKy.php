<?php
    class DangKy extends Controller{
        function display(){
            $this->View('DangKy');
        }

        
    }

?>